create definer = root@localhost trigger member
    after insert
    on user
    for each row
begin 
 insert into user_member ( member_id ) 
 values( new.id ); 
end;

