create definer = root@localhost trigger avatar
    after insert
    on user
    for each row
begin 
 insert into user_avatar ( Avatar_id,Username ) 
 values( new.id,new.Username ); 
end;

