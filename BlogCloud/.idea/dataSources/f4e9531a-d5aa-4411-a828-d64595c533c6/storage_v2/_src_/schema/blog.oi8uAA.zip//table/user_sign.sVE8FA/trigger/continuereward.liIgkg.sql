create definer = root@localhost trigger continueReward
    after insert
    on user_sign
    for each row
begin 
 insert into user_continuereward ( continue_id ) 
 values( new.id ); 
end;

