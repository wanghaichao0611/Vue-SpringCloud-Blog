create definer = root@localhost trigger totalReward
    after insert
    on user_sign
    for each row
begin 
 insert into user_totalreward ( total_id ) 
 values( new.id ); 
end;

