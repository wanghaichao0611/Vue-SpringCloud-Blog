create definer = root@localhost trigger security_trigger
    after insert
    on user
    for each row
begin 
 insert into user_security ( user_id,Username ) 
 values( new.id,new.Username ); 
end;

