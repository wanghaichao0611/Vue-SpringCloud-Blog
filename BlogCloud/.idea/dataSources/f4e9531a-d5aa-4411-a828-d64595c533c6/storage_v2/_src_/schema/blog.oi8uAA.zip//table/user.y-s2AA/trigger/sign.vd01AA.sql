create definer = root@localhost trigger sign
    after insert
    on user
    for each row
begin 
 insert into user_sign ( Sign_id ) 
 values( new.id ); 
end;

