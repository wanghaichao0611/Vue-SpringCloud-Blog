create definer = root@localhost trigger msg_security
    after insert
    on user
    for each row
begin 
 insert into user_msg_security( user_id ) 
 values( new.id ); 
end;

