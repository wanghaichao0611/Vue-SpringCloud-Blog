create
    definer = root@localhost procedure updateSign(IN signId int)
BEGIN
DECLARE Consign int;
SELECT Continue_sign into Consign from user_sign WHERE Sign_id=signId;
IF (0<Consign && Consign  <=5) THEN
UPDATE user_sign SET Total_sign=Total_sign+1,Continue_sign=Continue_sign+1,Experience=Experience+3
WHERE Sign_id=signId;
ELSEIF (5<Consign && Consign<=30) THEN
UPDATE user_sign SET Total_sign=Total_sign+1,Continue_sign=Continue_sign+1,Experience=Experience+5
WHERE Sign_id=signId;
ELSEIF (30<Consign && Consign<=90) THEN
UPDATE user_sign SET Total_sign=Total_sign+1,Continue_sign=Continue_sign+1,Experience=Experience+7
WHERE Sign_id=signId;
ELSEIF (90<Consign && Consign<=180) THEN
UPDATE user_sign SET Total_sign=Total_sign+1,Continue_sign=Continue_sign+1,Experience=Experience+9
WHERE Sign_id=signId;
ELSEIF (180<Consign && Consign<=360) THEN
UPDATE user_sign SET Total_sign=Total_sign+1,Continue_sign=Continue_sign+1,Experience=Experience+11
WHERE Sign_id=signId;
ELSEIF (360<Consign && Consign<=720) THEN
UPDATE user_sign SET Total_sign=Total_sign+1,Continue_sign=Continue_sign+1,Experience=Experience+13
WHERE Sign_id=signId;
ELSE 
UPDATE user_sign SET Total_sign=Total_sign+1,Continue_sign=Continue_sign+1,Experience=Experience+15
WHERE Sign_id=signId;
END IF;
END;

