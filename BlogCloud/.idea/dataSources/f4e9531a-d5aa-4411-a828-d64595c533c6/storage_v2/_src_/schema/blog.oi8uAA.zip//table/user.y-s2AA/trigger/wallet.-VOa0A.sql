create definer = root@localhost trigger wallet
    after insert
    on user
    for each row
begin 
 insert into user_wallet ( wallet_id ) 
 values( new.id ); 
end;

